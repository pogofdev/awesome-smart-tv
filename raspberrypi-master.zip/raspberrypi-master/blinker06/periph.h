
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void uart_putc ( unsigned int );
void hexstrings ( unsigned int );
void hexstring ( unsigned int );
int uart_init ( void );
void init_timer ( void );
unsigned int timer_tick ( void );
void toggle_led ( void );
void init_led ( void );
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
