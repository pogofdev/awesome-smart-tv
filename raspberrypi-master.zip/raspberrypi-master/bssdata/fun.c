

unsigned int fun2 ( unsigned int );
const unsigned int x=2;
unsigned int y;
unsigned int z=7;
void fun ( unsigned int a )
{
    unsigned int n;

    n=5;
    fun2(a);
    fun2(x);
    fun2(y);
    fun2(z);
    fun2(n);
}

