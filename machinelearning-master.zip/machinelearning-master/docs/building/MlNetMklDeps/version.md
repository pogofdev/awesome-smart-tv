#Intel MKl SDK versions used to build the MlNetMklDeps v0.0.0.4-0.0.0.7

##Sdk Version
linux and windows: mkl 2018 update 3
mac: mkl 2018 update 1

##Exact versions, including minors
mac: 2018.1.126
linux: 2018.3.222
windows: 2018.3.210