﻿using Microsoft.ML.Samples.Dynamic;

namespace Microsoft.ML.Samples
{
    internal static class Program
    {
        static void Main(string[] args)
        {
            TensorFlowTransformExample.TensorFlowScoringSample();
        }
    }
}
